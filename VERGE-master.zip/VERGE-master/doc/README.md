Verge 0.4.0

Copyright (c) 2013 Verge Developers
Copyright (c) 2011-2012 PPCoin Developers
Copyright (c) 2009-2012 Bitcoin Developers

Distributed under the MIT/X11 software license, see the accompanying LICENSE file or http://www.opensource.org/licenses/mit-license.php.
This product includes software developed by the OpenSSL Project for use in the OpenSSL Toolkit (http://www.openssl.org/).  This product includes cryptographic software written by Eric Young (eay@cryptsoft.com).


# Intro
Verge is a free open source project with the goal of providing a long-term energy-efficient multi-algorithm crypto-currency. Built on the foundation of Bitcoin and PPCoin, innovations such as Stealth transactions and Tor support help further advance the field of crypto-currency.
