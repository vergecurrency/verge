#ifndef QTIPCSERVER_H
#define QTIPCSERVER_H

// Define VERGE-Qt message queue name
#define VERGEURI_QUEUE_NAME "VERGEURI"

void ipcScanRelay(int argc, char *argv[]);
void ipcInit(int argc, char *argv[]);

#endif // QTIPCSERVER_H
