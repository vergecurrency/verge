<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="fr">
<defaultcodec>UTF-8</defaultcodec>
<context>
    <name>AboutDialog</name>
    <message>
        <location filename="../forms/aboutdialog.ui" line="+14"/>
        <source>About VERGE</source>
        <translation>A propos de VERGE</translation>
    </message>
    <message>
        <location line="+39"/>
        <source>&lt;b&gt;VERGE&lt;/b&gt; version</source>
        <translation>&lt;b&gt;VERGE&lt;/b&gt; version</translation>
    </message>
    <message>
        <location line="+41"/>
        <source>Copyright © 2014-2016 The Verge developers</source>
        <translation>Copyright © 2014-2016 The Verge developers</translation>
    </message>
    <message>
        <location line="+13"/>
        <source>
This is experimental software.

Distributed under the MIT/X11 software license, see the accompanying file COPYING or http://www.opensource.org/licenses/mit-license.php.

This product includes software developed by the OpenSSL Project for use in the OpenSSL Toolkit (http://www.openssl.org/) and cryptographic software written by Eric Young (eay@cryptsoft.com) and UPnP software written by Thomas Bernard.</source>
        <translation>
Il s&apos;agit d&apos;un logiciel expérimental.

Distribué sous license logicielle MIT/X11, voir le fichier inclus COPYING ou http://www.opensource.org/licenses/mit-license.php.

Ce produit inclut des logiciel développés par OpenSSL Project pour utilisation dans le OpenSSL Toolkit (http://www.openssl.org/) et cryptographic software par Eric Young (eay@cryptsoft.com) et UPnP software par Thomas Bernard.</translation>
    </message>
</context>
<context>
    <name>AddressBookPage</name>
    <message>
        <location filename="../forms/addressbookpage.ui" line="+14"/>
        <source>Address Book</source>
        <translation>Répertoire d&apos;adresses</translation>
    </message>
    <message>
        <location line="+22"/>
        <source>Double-click to edit address or label</source>
        <translation>Double-click pour éditer une adresse ou un label</translation>
    </message>
    <message>
        <location line="+27"/>
        <source>Create a new address</source>
        <translation>Créer une nouvelle adresse</translation>
    </message>
    <message>
        <location line="+14"/>
        <source>Copy the currently selected address to the system clipboard</source>
        <translation>Copier l&apos;adresse sélectionnée dans le presse papier</translation>
    </message>
    <message>
        <location line="-11"/>
        <source>&amp;New Address</source>
        <translation>&amp;Nouvelle Adresse</translation>
    </message>
    <message>
        <location line="-46"/>
        <source>These are your VERGE addresses for receiving payments. You may want to give a different one to each sender so you can keep track of who is paying you.</source>
        <translation>Voici vos adresses VERGE addresses pour recevoir des paiements. Vous pouvez en fournir une différente pour chaque émetteur, afin de suivre qui vous a payé.</translation>
    </message>
    <message>
        <location line="+60"/>
        <source>&amp;Copy Address</source>
        <translation>&amp;Copier l&apos;Adresse</translation>
    </message>
    <message>
        <location line="+11"/>
        <source>Show &amp;QR Code</source>
        <translation>Montrer &amp;QR Code</translation>
    </message>
    <message>
        <location line="+11"/>
        <source>Sign a message to prove you own a VERGE address</source>
        <translation>Signer un message pour prouver que vous avez une adresse VERGE</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Sign &amp;Message</source>
        <translation> Signer Message</translation>
    </message>
    <message>
        <location line="+25"/>
        <source>Delete the currently selected address from the list</source>
        <translation>Supprimer l&apos;Adresse sélectionnée de la lise</translation>
    </message>
    <message>
        <location line="-14"/>
        <source>Verify a message to ensure it was signed with a specified VERGE address</source>
        <translation>Vérifier un message pour s&apos;assurer qu&apos;il a été signé avec une adresse VERGE spécifiée</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>&amp;Verify Message</source>
        <translation>&amp;Verifier le Message</translation>
    </message>
    <message>
        <location line="+14"/>
        <source>&amp;Delete</source>
        <translation>&amp;Supprimer</translation>
    </message>
    <message>
        <location filename="../addressbookpage.cpp" line="+65"/>
        <source>Copy &amp;Label</source>
        <translation>Copier &amp;Label</translation>
    </message>
    <message>
        <location line="+2"/>
        <source>&amp;Editer</source>
        <translation>&amp;Editer</translation>
    </message>
    <message>
        <location line="+250"/>
        <source>Export Address Book Data</source>
        <translation>Exporter le Répertoire d&apos;Adresses</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Comma separated file (*.csv)</source>
        <translation>Comma separated file (*.csv)</translation>
    </message>
    <message>
        <location line="+13"/>
        <source>Error exporting</source>
        <translation>Erreur d&apos;exportation</translation>
    </message>
    <message>
        <location line="+0"/>
        <source>Could not write to file %1.</source>
        <translation>Impossible d&apos;écrire dans le fichier %1.</translation>
    </message>
</context>
<context>
    <name>AddressTableModel</name>
    <message>
        <location filename="../addresstablemodel.cpp" line="+142"/>
        <source>Label</source>
        <translation>Label</translation>
    </message>
    <message>
        <location line="+0"/>
        <source>Address</source>
        <translation>Addresse</translation>
    </message>
    <message>
        <location line="+36"/>
        <source>(no label)</source>
        <translation>(pas de label)</translation>
    </message>
</context>
<context>
    <name>AskPassphraseDialog</name>
    <message>
        <location filename="../forms/askpassphrasedialog.ui" line="+26"/>
        <source>Passphrase Dialog</source>
        <translation>Passphrase Dialog</translation>
    </message>
    <message>
        <location line="+21"/>
        <source>Enter passphrase</source>
        <translation>Entrer la passphrase</translation>
    </message>
    <message>
        <location line="+14"/>
        <source>New passphrase</source>
        <translation>Nouvelle passphrase</translation>
    </message>
    <message>
        <location line="+14"/>
        <source>Repeat new passphrase</source>
        <translation>Répéter la nouvelle passphrase</translation>
    </message>
    <message>
        <location filename="../askpassphrasedialog.cpp" line="+33"/>
        <source>Enter the new passphrase to the wallet.&lt;br/&gt;Please use a passphrase of &lt;b&gt;10 or more random characters&lt;/b&gt;, or &lt;b&gt;eight or more words&lt;/b&gt;.</source>
        <translation>Entrer la nouvelle passphrase dans le wallet.&lt;br/&gt;Merci d&apos;utiliser une passphrase de &lt;b&gt;10 caractères aléatoires ou plus &lt;/b&gt;, ou &lt;b&gt;huit mots ou plus&lt;/b&gt;.</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Encrypt wallet</source>
        <translation>Encrypter le wallet</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>This operation needs your wallet passphrase to unlock the wallet.</source>
        <translation>Cette opération necéssite votre passphrase de wallet pour dévérouiller votre wallet.</translation>
    </message>
    <message>
        <location line="+5"/>
        <source>Unlock wallet</source>
        <translation>Dévérouiller wallet</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>This operation needs your wallet passphrase to decrypt the wallet.</source>
        <translation>Cette opération necéssite votre passphrase de wallet pour décrypter le wallet.</translation>
    </message>
    <message>
        <location line="+5"/>
        <source>Decrypt wallet</source>
        <translation>Decrypter wallet</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Change passphrase</source>
        <translation>Changer passphrase</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Enter the old and new passphrase to the wallet.</source>
        <translation>Entrer l&apos;ancienne and la nouvelle passphrase dans le wallet.</translation>
    </message>
    <message>
        <location line="+46"/>
        <source>Confirm wallet encryption</source>
        <translation>Confirmer l&apos;encryption du wallet</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Warning: If you encrypt your wallet and lose your passphrase, you will &lt;b&gt;LOSE ALL OF YOUR COINS&lt;/b&gt;!</source>
        <translation>Attention: si vous encryptez votre wallet et perdez votre passphrase, vous allez &lt;b&gt;PERDRE TOUS VOS COINS&lt;/b&gt;!</translation>
    </message>
    <message>
        <location line="+0"/>
        <source>Are you sure you wish to encrypt your wallet?</source>
        <translation>Etes vous sûr de vouloir encrypter votre wallet?</translation>
    </message>
    <message>
        <location line="+15"/>
        <source>IMPORTANT: Any previous backups you have made of your wallet file should be replaced with the newly generated, encrypted wallet file. For security reasons, previous backups of the unencrypted wallet file will become useless as soon as you start using the new, encrypted wallet.</source>
        <translation>IMPORTANT: touts sauvegarde antérieure de votre wallet devrait être remplacée par la nouvelle version générée et enccryptée. Pour des raisons de sécurité, les sauvegardes précédentes du wallet non crypté vont devenir inutilisables dès lors que vous commencerez à utiliser le nouveau wallet encrypté.</translation>
    </message>
    <message>
        <location line="+100"/>
        <location line="+24"/>
        <source>Warning: The Caps Lock key is on!</source>
        <translation>Attention: La touche Caps Lock (Majuscules) est active!</translation>
    </message>
    <message>
        <location line="-130"/>
        <location line="+58"/>
        <source>Wallet encrypted</source>
        <translation>Wallet encrypté</translation>
    </message>
    <message>
        <location line="-56"/>
        <source>VERGE will close now to finish the encryption process. Remember that encrypting your wallet cannot fully protect your coins from being stolen by malware infecting your computer.</source>
        <translation>VERGE va bientôt finir le processus d&apos;encryption. Rappelez-vous qu&apos;encrypter votre waller ne peut pas protéger totalement contre le vol par malwares pouvant infecter votre ordinateur.</translation>
    </message>
    <message>
        <location line="+13"/>
        <location line="+7"/>
        <location line="+42"/>
        <location line="+6"/>
        <source>Wallet encryption failed</source>
        <translation>L&apos;encryption du wallet a échouée</translation>
    </message>
    <message>
        <location line="-54"/>
        <source>Wallet encryption failed due to an internal error. Your wallet was not encrypted.</source>
        <translation>L&apos;encryption du wallet a échouée à cause d&apos;une erreur interne. Votre wallet n&apos;est pas encrypté.</translation>
    </message>
    <message>
        <location line="+7"/>
        <location line="+48"/>
        <source>The supplied passphrases do not match.</source>
        <translation>La passphrase fournie ne correspond pas.</translation>
    </message>
    <message>
        <location line="-37"/>
        <source>Wallet unlock failed</source>
        <translation>Echec du dévérouillage de wallet</translation>
    </message>
    <message>
        <location line="+1"/>
        <location line="+11"/>
        <location line="+19"/>
        <source>The passphrase entered for the wallet decryption was incorrect.</source>
        <translation>la passphrase fournie pour le décryptage du wallet est incorrecte</translation>
    </message>
    <message>
        <location line="-20"/>
        <source>Wallet decryption failed</source>
        <translation>Echec du décryptage du wallet</translation>
    </message>
    <message>
        <location line="+14"/>
        <source>Wallet passphrase was successfully changed.</source>
        <translation>La passphrase du wallet a été changée avec succès</translation>
    </message>
</context>
<context>
    <name>BitcoinGUI</name>
    <message>
        <location filename="../bitcoingui.cpp" line="+257"/>
        <source>Sign &amp;message...</source>
        <translation>Signer &amp;message...</translation>
    </message>
    <message>
        <location line="+237"/>
        <source>Synchronizing with network...</source>
        <translation>Synchronisation avec le réseau...</translation>
    </message>
    <message>
        <location line="-299"/>
        <source>&amp;Overview</source>
        <translation>&amp;Aperçu</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Show general overview of wallet</source>
        <translation>Montrer un aperçu général du wallet</translation>
    </message>
    <message>
        <location line="+17"/>
        <source>&amp;Transactions</source>
        <translation>&amp;Transactions</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Browse transaction history</source>
        <translation>Parcourir l&apos;historique de transactions</translation>
    </message>
    <message>
        <location line="+5"/>
        <source>&amp;Address Book</source>
        <translation>&amp;Répertoire d&apos;adresses</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Edit the list of stored addresses and labels</source>
        <translation>Editer la liste d&apos;adresses et de labels enregistrés</translation>
    </message>
    <message>
        <location line="-13"/>
        <source>&amp;Receive coins</source>
        <translation>&amp;Recevoir des coins</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Show the list of addresses for receiving payments</source>
        <translation>Montrer la liste d&apos;adresses pour recevoir des paiements</translation>
    </message>
    <message>
        <location line="-7"/>
        <source>&amp;Send coins</source>
        <translation>&amp;Envoyer des coins</translation>
    </message>
    <message>
        <location line="+35"/>
        <source>E&amp;xit</source>
        <translation>E&amp;xit</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Quit application</source>
        <translation>Quitter l&apos;application</translation>
    </message>
    <message>
        <location line="+4"/>
        <source>Show information about VERGE</source>
        <translation>Montrer les informations à propos de VERGE</translation>
    </message>
    <message>
        <location line="+2"/>
        <source>About &amp;Qt</source>
        <translation>A propos de &amp;Qt</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Show information about Qt</source>
        <translation>Montrer les informations à propos de Qt</translation>
    </message>
    <message>
        <location line="+2"/>
        <source>&amp;Options...</source>
        <translation>&amp;Options...</translation>
    </message>
    <message>
        <location line="+4"/>
        <source>&amp;Encrypt Wallet...</source>
        <translation>&amp;Encrypter le Wallet...</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>&amp;Backup Wallet...</source>
        <translation>&amp;Sauvegarde du Wallet...</translation>
    </message>
    <message>
        <location line="+2"/>
        <source>&amp;Change Passphrase...</source>
        <translation>&amp;Changer la Passphrase...</translation>
    </message>
    <message numerus="yes">
        <location line="+241"/>
        <source>~%n block(s) remaining</source>
        <translation>
            <numerusform>~%n block restant</numerusform>
            <numerusform>~%n blocks restants</numerusform>
        </translation>
    </message>
    <message>
        <location line="+6"/>
        <source>Downloaded %1 of %2 blocks of transaction history (%3% done).</source>
        <translation>%1 des %2 blocks de l&apos;historique de transactions ont été téléchargés (%3% effectués).</translation>
    </message>
    <message>
        <location line="-242"/>
        <source>&amp;Export...</source>
        <translation>&amp;Exporter...</translation>
    </message>
    <message>
        <location line="-58"/>
        <source>Send coins to a VERGE address</source>
        <translation>Envoyer des coins à une adresse VERGE</translation>
    </message>
    <message>
        <location line="+45"/>
        <source>Modify configuration options for VERGE</source>
        <translation>Modifier les options de configuration de VERGE</translation>
    </message>
    <message>
        <location line="+14"/>
        <source>Export the data in the current tab to a file</source>
        <translation>Exporter les données courrantes (Tab) dans un fichier</translation>
    </message>
    <message>
        <location line="-10"/>
        <source>Encrypt or decrypt wallet</source>
        <translation>Encrypter ou decrypter wallet</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Backup wallet to another location</source>
        <translation>Sauvegrader le wallet à un autre endroit</translation>
    </message>
    <message>
        <location line="+2"/>
        <source>Change the passphrase used for wallet encryption</source>
        <translation>Changer la passphrase utilisée pour encrypter le wallet</translation>
    </message>
    <message>
        <location line="+6"/>
        <source>&amp;Debug window</source>
        <translation>Fenêtre de &amp;Debuggage</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Open debugging and diagnostic console</source>
        <translation>ouvrir la console de debugging et diagnostic</translation>
    </message>
    <message>
        <location line="-5"/>
        <source>&amp;Verify message...</source>
        <translation>&amp;Verifier message...</translation>
    </message>
    <message>
        <location line="-186"/>
        <source>VERGE</source>
        <translation>VERGE</translation>
    </message>
    <message>
        <location line="+0"/>
        <source>Wallet</source>
        <translation>Wallet</translation>
    </message>
    <message>
        <location line="+168"/>
        <source>&amp;About VERGE</source>
        <translation>&amp;A propos de VERGE</translation>
    </message>
    <message>
        <location line="+9"/>
        <source>&amp;Show / Hide</source>
        <translation>&amp;Montrer / Cacher</translation>
    </message>
    <message>
        <location line="+39"/>
        <source>&amp;File</source>
        <translation>&amp;Fichier</translation>
    </message>
    <message>
        <location line="+8"/>
        <source>&amp;Settings</source>
        <translation>&amp;Paramètres</translation>
    </message>
    <message>
        <location line="+6"/>
        <source>&amp;Help</source>
        <translation>&amp;Aide</translation>
    </message>
    <message>
        <location line="+9"/>
        <source>Tabs toolbar</source>
        <translation>Tabs toolbar</translation>
    </message>
    <message>
        <location line="+8"/>
        <source>Actions toolbar</source>
        <translation>Actions toolbar</translation>
    </message>
    <message>
        <location line="+13"/>
        <location line="+9"/>
        <source>[testnet]</source>
        <translation>[testnet]</translation>
    </message>
    <message>
        <location line="+0"/>
        <location line="+60"/>
        <source>VERGE client</source>
        <translation>client VERGE</translation>
    </message>
    <message numerus="yes">
        <location line="+69"/>
        <source>%n active connection(s) to VERGE network</source>
        <translation>
            <numerusform>%n connexions active au réseau VERGE</numerusform>
            <numerusform>%n connexions actives au réseau VERGE</numerusform>
        </translation>
    </message>
    <message>
        <location line="+40"/>
        <source>Downloaded %1 blocks of transaction history.</source>
        <translation>%1 blocks de l&apos;historique de transactions a été téléchargé.</translation>
    </message>
    <message numerus="yes">
        <location line="+22"/>
        <source>%n second(s) ago</source>
        <translation>
            <numerusform>il y a %n seconde</numerusform>
            <numerusform>il y a %n secondes</numerusform>
        </translation>
    </message>
    <message numerus="yes">
        <location line="+4"/>
        <source>%n minute(s) ago</source>
        <translation>
            <numerusform>il y a %n minute</numerusform>
            <numerusform>il y a %n minutes</numerusform>
        </translation>
    </message>
    <message numerus="yes">
        <location line="+4"/>
        <source>%n hour(s) ago</source>
        <translation>
            <numerusform>il y a %n heure</numerusform>
            <numerusform>il y a %n heures</numerusform>
        </translation>
    </message>
    <message numerus="yes">
        <location line="+4"/>
        <source>%n day(s) ago</source>
        <translation>
            <numerusform>il y a %n jour</numerusform>
            <numerusform>il y a %n jours</numerusform>
        </translation>
    </message>
    <message>
        <location line="+6"/>
        <source>Up to date</source>
        <translation>A jour</translation>
    </message>
    <message>
        <location line="+7"/>
        <source>Catching up...</source>
        <translation>Rattrapage en cours...</translation>
    </message>
    <message>
        <location line="+10"/>
        <source>Last received block was generated %1.</source>
        <translation>Le dernier bloc reçu a été généré %1.</translation>
    </message>
    <message>
        <location line="+59"/>
        <source>This transaction is over the size limit.  You can still send it for a fee of %1, which goes to the nodes that process your transaction and helps to support the network.  Do you want to pay the fee?</source>
        <translation>Cette transaction est plus grande que la taille limite2 Vous pouvez toutefois l&apos;envoyer avec des frais de %1, qui iront aux noeuds qui vont exécuter votre transaction et aider à support le réseau. Voulez-vous payer les frais ?</translation>
    </message>
    <message>
        <location line="+5"/>
        <source>Confirm transaction fee</source>
        <translation>Confirmer les frais de transaction</translation>
    </message>
    <message>
        <location line="+27"/>
        <source>Sent transaction</source>
        <translation>Transaction envoyée</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Incoming transaction</source>
        <translation>Transaction entrante</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Date: %1
Quantité: %2
Type: %3
Addresse: %4
</source>
        <translation>Date: %1
Quantité: %2
Type: %3
Addresse: %4
</translation>
    </message>
    <message>
        <location line="+100"/>
        <location line="+15"/>
        <source>URI handling</source>
        <translation>URI handling</translation>
    </message>
    <message>
        <location line="-15"/>
        <location line="+15"/>
        <source>URI can not be parsed! This can be caused by an invalid VERGE address or malformed URI parameters.</source>
        <translation>URI ne peut pas être analysée! Celà peut être dû à une adresse VERGE invalide ou des paramêtres URI malformés.</translation>
    </message>
    <message>
        <location line="+16"/>
        <source>Wallet is &lt;b&gt;encrypted&lt;/b&gt; and currently &lt;b&gt;unlocked&lt;/b&gt;</source>
        <translation>Le portefeuille est &lt;b&gt;encrypté&lt;/b&gt; et actuellement &lt;b&gt;dévérouillé&lt;/b&gt;</translation>
    </message>
    <message>
        <location line="+8"/>
        <source>Wallet is &lt;b&gt;encrypted&lt;/b&gt; and currently &lt;b&gt;locked&lt;/b&gt;</source>
        <translation>Le portefeuille est &lt;b&gt;encrypté&lt;/b&gt; et actuellement &lt;b&gt;vérouillé&lt;/b&gt;</translation>
    </message>
    <message>
        <location line="+23"/>
        <source>Backup Wallet</source>
        <translation>Sauvegrade portefeuille</translation>
    </message>
    <message>
        <location line="+0"/>
        <source>Wallet Data (*.dat)</source>
        <translation>Données de portefeuille (*.dat)</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Backup Failed</source>
        <translation>Sauvegade échouée</translation>
    </message>
    <message>
        <location line="+0"/>
        <source>There was an error trying to save the wallet data to the new location.</source>
        <translation>il y a eu une erreur lors de la sauvegarde du portefeuille vers une nouvelle destination.</translation>
    </message>
    <message>
        <location filename="../bitcoin.cpp" line="+109"/>
        <source>A fatal error occurred. VERGE can no longer continue safely and will quit.</source>
        <translation>Erreur fatale. VERGE ne peut plus continuer à être exécuté et va s&apos;arrêter.</translation>
    </message>
</context>
<context>
    <name>ClientModel</name>
    <message>
        <location filename="../clientmodel.cpp" line="+87"/>
        <source>Network Alert</source>
        <translation>Alerte Réseau</translation>
    </message>
</context>
<context>
    <name>EditAddressDialog</name>
    <message>
        <location filename="../forms/editaddressdialog.ui" line="+14"/>
        <source>Edit Address</source>
        <translation>Editer Adresse</translation>
    </message>
    <message>
        <location line="+11"/>
        <source>&amp;Label</source>
        <translation>&amp;Label</translation>
    </message>
    <message>
        <location line="+10"/>
        <source>The label associated with this address book entry</source>
        <translation>Label associé avec cette entrée du répertoire d&apos;adresses</translation>
    </message>
    <message>
        <location line="+7"/>
        <source>&amp;Address</source>
        <translation>&amp;Adresse</translation>
    </message>
    <message>
        <location line="+10"/>
        <source>The address associated with this address book entry. This can only be modified for sending addresses.</source>
        <translation>Label associé avec cette entrée du répertoire d&apos;adresses. Ne peut être modifié que pour les adresses d&apos;envoi.</translation>
    </message>
    <message>
        <location filename="../editaddressdialog.cpp" line="+20"/>
        <source>New receiving address</source>
        <translation>Nouvelle adresse de réception</translation>
    </message>
    <message>
        <location line="+4"/>
        <source>New sending address</source>
        <translation>Nouvelle adresse d&apos;envoi</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Edit receiving address</source>
        <translation>Editer l&apos;adresse de réception</translation>
    </message>
    <message>
        <location line="+4"/>
        <source>Edit sending address</source>
        <translation>Editer l&apos;adresse d&apos;envoi</translation>
    </message>
    <message>
        <location line="+60"/>
        <source>The entered address &quot;%1&quot; is already in the address book.</source>
        <translation>L&apos;adresse entrée &quot;%1&quot; existe déjà dans le répertoire d&apos;adresses.</translation>
    </message>
    <message>
        <location line="+5"/>
        <source>The entered address &quot;%1&quot; is not a valid VERGE address.</source>
        <translation>L&apos;adresse entrée &quot;%1&quot; n&apos;est pas une adresse VERGE valide.</translation>
    </message>
    <message>
        <location line="+5"/>
        <source>Could not unlock wallet.</source>
        <translation>Impossible de dévérouiller le portefeuille.</translation>
    </message>
    <message>
        <location line="+5"/>
        <source>New key generation failed.</source>
        <translation>la génération d&apos;une nouvelle clé a échouée</translation>
    </message>
</context>
<context>
    <name>GUIUtil::HelpMessageBox</name>
    <message>
        <location filename="../guiutil.cpp" line="+419"/>
        <location line="+12"/>
        <source>VERGE-Qt</source>
        <translation>VERGE-Qt</translation>
    </message>
    <message>
        <location line="-12"/>
        <source>version</source>
        <translation>version</translation>
    </message>
    <message>
        <location line="+2"/>
        <source>Usage:</source>
        <translation>Utilisation:</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>command-line options</source>
        <translation>Options de ligne de commandes</translation>
    </message>
    <message>
        <location line="+4"/>
        <source>UI options</source>
        <translation>Options d&apos;interface Utilisateur</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Set language, for example &quot;de_DE&quot; (default: system locale)</source>
        <translation>Définir la langue, par exemple &quot;de_DE&quot; (default: system locale)</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Start minimized</source>
        <translation>Démarrer réduit</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Show splash screen on startup (default: 1)</source>
        <translation>Montrer le l&apos;écran de démarrage (default: 1)</translation>
    </message>
</context>
<context>
    <name>OptionsDialog</name>
    <message>
        <location filename="../forms/optionsdialog.ui" line="+14"/>
        <source>Options</source>
        <translation>Options</translation>
    </message>
    <message>
        <location line="+16"/>
        <source>&amp;Main</source>
        <translation>&amp;Général</translation>
    </message>
    <message>
        <location line="+6"/>
        <source>Optional transaction fee per kB that helps make sure your transactions are processed quickly. Most transactions are 1 kB. Fee 0.01 recommended.</source>
        <translation>Frais de transactions optionnels par kB, qui aideront à assurer un traitement rapide de votre transaction. La plupart des transactions font 1 kB. Frais de 0.01 recommendés.</translation>
    </message>
    <message>
        <location line="+15"/>
        <source>Pay transaction &amp;fee</source>
        <translation>Payer &amp;les frais de transaction</translation>
    </message>
    <message>
        <location line="+31"/>
        <source>Automatically start VERGE after logging in to the system.</source>
        <translation>Démarrer automatiquementVERGE après l&apos;authentification sur le système.</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>&amp;Start VERGE on system login</source>
        <translation>&amp;Démarrer VERGE lors de l&apos;authentification sur le système</translation>
    </message>
    <message>
        <location line="+7"/>
        <source>Detach block and address databases at shutdown. This means they can be moved to another data directory, but it slows down shutdown. The wallet is always detached.</source>
        <translation>Détacher les bases de données de blocs et d&apos;addresses lors de l&apos;arrêt. Celà signifie qu&apos;ils pourront être déplacés vers un autre emplacement, mais celà ralentit l&apos;arrêt. Le portefeuille est toujours détaché.</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>&amp;Detach databases at shutdown</source>
        <translation>&amp;Détacher les bases de données lors de l&apos;arrêt</translation>
    </message>
    <message>
        <location line="+21"/>
        <source>&amp;Network</source>
        <translation>&amp;Réseau</translation>
    </message>
    <message>
        <location line="+6"/>
        <source>Automatically open the VERGE client port on the router. This only works when your router supports UPnP and it is enabled.</source>
        <translation>Ouvrir automatiquement le port du client VERGE sur le routeur. Celà ne marche que si votre routeur supporte UPnP et qu&apos;il est activé.</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Map port using &amp;UPnP</source>
        <translation>Mapper le port en utilisant &amp;UPnP</translation>
    </message>
    <message>
        <location line="+7"/>
        <source>Connect to the VERGE network through a SOCKS proxy (e.g. when connecting through Tor).</source>
        <translation>Se connecter au réseau VERGE à travers un proxy SOCKS (ex: lors d&apos;une connexion via TOR).</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>&amp;Connect through SOCKS proxy:</source>
        <translation>&amp;Se connecter à travers un proxy SOCKS:</translation>
    </message>
    <message>
        <location line="+9"/>
        <source>Proxy &amp;IP:</source>
        <translation>&amp;IP du Proxy</translation>
    </message>
    <message>
        <location line="+19"/>
        <source>IP address of the proxy (e.g. 127.0.0.1)</source>
        <translation>Adresse IP du proxy (ex: 127.0.0.1)</translation>
    </message>
    <message>
        <location line="+7"/>
        <source>&amp;Port:</source>
        <translation>&amp;Port:</translation>
    </message>
    <message>
        <location line="+19"/>
        <source>Port of the proxy (e.g. 9050)</source>
        <translation>Port du Proxy (ex: 9050)</translation>
    </message>
    <message>
        <location line="+7"/>
        <source>SOCKS &amp;Version:</source>
        <translation>&amp;Version SOCKS:</translation>
    </message>
    <message>
        <location line="+13"/>
        <source>SOCKS version of the proxy (e.g. 5)</source>
        <translation>Version SOCKS du proxy (e.g. 5)</translation>
    </message>
    <message>
        <location line="+36"/>
        <source>&amp;Window</source>
        <translation>&amp;Fenêtre</translation>
    </message>
    <message>
        <location line="+6"/>
        <source>Show only a tray icon after minimizing the window.</source>
        <translation>Ne montrer une icône dans la barre de tâche qu&apos;une fois la fenêtre minimisée</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>&amp;Minimize to the tray instead of the taskbar</source>
        <translation>&amp;Minimiser dans la zone de notifications plutôt que dans la barre des tâches</translation>
    </message>
    <message>
        <location line="+7"/>
        <source>Minimize instead of exit the application when the window is closed. When this option is enabled, the application will be closed only after selecting Quit in the menu.</source>
        <translation>Minimiser au lieu de fermer l&apos;application lors de la fermeture de la fenêtre. Lorsque cette option est activée, l&apos;application sera fermée uniquement après avoir sélectionné Quitter dans le menu.</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>M&amp;inimize on close</source>
        <translation>M&amp;inimiser sur fermeture</translation>
    </message>
    <message>
        <location line="+21"/>
        <source>&amp;Display</source>
        <translation>&amp;Affichage</translation>
    </message>
    <message>
        <location line="+8"/>
        <source>User Interface &amp;language:</source>
        <translation>&amp;Langue d&apos;interface utilisateur:</translation>
    </message>
    <message>
        <location line="+13"/>
        <source>The user interface language can be set here. This setting will take effect after restarting VERGE.</source>
        <translation>La langue de l&apos;interface utilisateur peut ête définie ici. Ce paramêtre sera pris en compte après un redémarrage de VERGE.</translation>
    </message>
    <message>
        <location line="+11"/>
        <source>&amp;Unit to show amounts in:</source>
        <translation>&amp;Unité des montants:</translation>
    </message>
    <message>
        <location line="+13"/>
        <source>Choose the default subdivision unit to show in the interface and when sending coins.</source>
        <translation>Choisir la subdivision par défaut à montrer dans l&apos;interface et lors de l&apos;envoi des pièces.</translation>
    </message>
    <message>
        <location line="+9"/>
        <source>Whether to show VERGE addresses in the transaction list or not.</source>
        <translation>Montrer ou non les adresses VERGE dans la liste de transactions.</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>&amp;Display addresses in transaction list</source>
        <translation>&amp;Afficher les adresses dans la liste de transactions</translation>
    </message>
    <message>
        <location line="+71"/>
        <source>&amp;OK</source>
        <translation>&amp;OK</translation>
    </message>
    <message>
        <location line="+7"/>
        <source>&amp;Cancel</source>
        <translation>&amp;Annuler</translation>
    </message>
    <message>
        <location line="+10"/>
        <source>&amp;Apply</source>
        <translation>&amp;Appliquer</translation>
    </message>
    <message>
        <location filename="../optionsdialog.cpp" line="+55"/>
        <source>default</source>
        <translation>Défaut</translation>
    </message>
    <message>
        <location line="+147"/>
        <location line="+9"/>
        <source>Warning</source>
        <translation>Attention</translation>
    </message>
    <message>
        <location line="-9"/>
        <location line="+9"/>
        <source>This setting will take effect after restarting VERGE.</source>
        <translation>ce paramètre sera pris en compte après redémarrage de VERGE.</translation>
    </message>
    <message>
        <location line="+29"/>
        <source>The supplied proxy address is invalid.</source>
        <translation>L&apos;adresse de proxy fournie est invalide</translation>
    </message>
</context>
<context>
    <name>OverviewPage</name>
    <message>
        <location filename="../forms/overviewpage.ui" line="+14"/>
        <source>Form</source>
        <translation>formulaire</translation>
    </message>
    <message>
        <location line="+33"/>
        <location line="+183"/>
        <source>The displayed information may be out of date. Your wallet automatically synchronizes with the VERGE network after a connection is established, but this process has not completed yet.</source>
        <translation>L&apos;information affichée peut être périmée. Votre portefeuille se synchronise automatiquement avec le réseau VERGE dès qu&apos;une connexion est établie, mais ce processus n&apos;a pas encore abouti.</translation>
    </message>
    <message>
        <location line="-141"/>
        <source>Balance:</source>
        <translation>Balance:</translation>
    </message>
    <message>
        <location line="+118"/>
        <source>Stake:</source>
        <translation>Stake:</translation>
    </message>
    <message>
        <location line="+58"/>
        <source>Number of transactions:</source>
        <translation>Nombre de transactions:</translation>
    </message>
    <message>
        <location line="-29"/>
        <source>Unconfirmed:</source>
        <translation>Non confirmées:</translation>
    </message>
    <message>
        <location line="-78"/>
        <source>Wallet</source>
        <translation>Portefeuille</translation>
    </message>
    <message>
        <location line="+124"/>
        <source>Immature:</source>
        <translation>Immature:</translation>
    </message>
    <message>
        <location line="+13"/>
        <source>Mined balance that has not yet matured</source>
        <translation>Balance minée mais non encore mature</translation>
    </message>
    <message>
        <location line="+46"/>
        <source>&lt;b&gt;Recent transactions&lt;/b&gt;</source>
        <translation>&lt;b&gt;transactions récentes&lt;/b&gt;</translation>
    </message>
    <message>
        <location line="-118"/>
        <source>Your current balance</source>
        <translation>Votre balance actuelle</translation>
    </message>
    <message>
        <location line="+29"/>
        <source>Total of transactions that have yet to be confirmed, and do not yet count toward the current balance</source>
        <translation>Nombre de transaction restant à confirmer, et non encore comptabilisées pour l&apos;instant dans la balance.</translation>
    </message>
    <message>
        <location line="+134"/>
        <source>Total of coins that was staked, and do not yet count toward the current balance</source>
        <translation>Nombre de pièces jalonnées, et non encore comptabilisées pour l&apos;instant dans la balance.</translation>
    </message>
    <message>
        <location line="+20"/>
        <source>Total number of transactions in wallet</source>
        <translation>Nombre total de transactions dans le portefeuille</translation>
    </message>
    <message>
        <location filename="../overviewpage.cpp" line="+112"/>
        <location line="+1"/>
        <source>out of sync</source>
        <translation>Non synchronisé</translation>
    </message>
</context>
<context>
    <name>QRCodeDialog</name>
    <message>
        <location filename="../forms/qrcodedialog.ui" line="+14"/>
        <source>QR Code Dialog</source>
        <translation>Fenêtre QR Code</translation>
    </message>
    <message>
        <location line="+59"/>
        <source>Request Payment</source>
        <translation>Demander Paiement</translation>
    </message>
    <message>
        <location line="+56"/>
        <source>Amount:</source>
        <translation>Quantité:</translation>
    </message>
    <message>
        <location line="-44"/>
        <source>Label:</source>
        <translation>Label:</translation>
    </message>
    <message>
        <location line="+19"/>
        <source>Message:</source>
        <translation>Message:</translation>
    </message>
    <message>
        <location line="+71"/>
        <source>&amp;Save As...</source>
        <translation>&amp;Enregistrer sous...</translation>
    </message>
    <message>
        <location filename="../qrcodedialog.cpp" line="+62"/>
        <source>Error encoding URI into QR Code.</source>
        <translation>Erreur lors de l&apos;encodage de l&apos;URI en QR Code.</translation>
    </message>
    <message>
        <location line="+40"/>
        <source>The entered amount is invalid, please check.</source>
        <translation>Le montant entré est invalide, merci de vérifier.</translation>
    </message>
    <message>
        <location line="+23"/>
        <source>Resulting URI too long, try to reduce the text for label / message.</source>
        <translation>L&apos;URI resultante est trop longue, essayez de réduire le texte du label / message.</translation>
    </message>
    <message>
        <location line="+25"/>
        <source>Save QR Code</source>
        <translation>Sauvegarder QR Code</translation>
    </message>
    <message>
        <location line="+0"/>
        <source>PNG Images (*.png)</source>
        <translation>PNG Images (*.png)</translation>
    </message>
</context>
<context>
    <name>RPCConsole</name>
    <message>
        <location filename="../forms/rpcconsole.ui" line="+46"/>
        <source>Client name</source>
        <translation>Nom du client</translation>
    </message>
    <message>
        <location line="+10"/>
        <location line="+23"/>
        <location line="+26"/>
        <location line="+23"/>
        <location line="+23"/>
        <location line="+36"/>
        <location line="+53"/>
        <location line="+23"/>
        <location line="+23"/>
        <location filename="../rpcconsole.cpp" line="+348"/>
        <source>N/A</source>
        <translation>N/A</translation>
    </message>
    <message>
        <location line="-217"/>
        <source>Client version</source>
        <translation>Version du Client</translation>
    </message>
    <message>
        <location line="-45"/>
        <source>&amp;Information</source>
        <translation>&amp;Information</translation>
    </message>
    <message>
        <location line="+68"/>
        <source>Using OpenSSL version</source>
        <translation>Usilise la version OpenSSL</translation>
    </message>
    <message>
        <location line="+49"/>
        <source>Startup time</source>
        <translation>Temps de démarrage</translation>
    </message>
    <message>
        <location line="+29"/>
        <source>Network</source>
        <translation>Réseau</translation>
    </message>
    <message>
        <location line="+7"/>
        <source>Number of connections</source>
        <translation>Nombre de connexions</translation>
    </message>
    <message>
        <location line="+23"/>
        <source>On testnet</source>
        <translation>Sur testnet</translation>
    </message>
    <message>
        <location line="+23"/>
        <source>Block chain</source>
        <translation>Chaine de blocs</translation>
    </message>
    <message>
        <location line="+7"/>
        <source>Current number of blocks</source>
        <translation>Nombre actuel de blocs</translation>
    </message>
    <message>
        <location line="+23"/>
        <source>Estimated total blocks</source>
        <translation>Nombre total estimé de blocs</translation>
    </message>
    <message>
        <location line="+23"/>
        <source>Last block time</source>
        <translation>Temps du dernier bloc</translation>
    </message>
    <message>
        <location line="+52"/>
        <source>&amp;Open</source>
        <translation>&amp;Ouvert</translation>
    </message>
    <message>
        <location line="+16"/>
        <source>Command-line options</source>
        <translation>Options de ligne de commande</translation>
    </message>
    <message>
        <location line="+7"/>
        <source>Show the VERGE-Qt help message to get a list with possible VERGE command-line options.</source>
        <translation>Montrer les messages d&apos;aide VERGE-Qt pour avoir une liste des options de ligne de commande VERGE possibles.</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>&amp;Show</source>
        <translation>&amp;Montrer</translation>
    </message>
    <message>
        <location line="+24"/>
        <source>&amp;Console</source>
        <translation>&amp;Console</translation>
    </message>
    <message>
        <location line="-260"/>
        <source>Build date</source>
        <translation>Date de Build</translation>
    </message>
    <message>
        <location line="-104"/>
        <source>VERGE - Debug window</source>
        <translation>VERGE - Fenêtre de Debug</translation>
    </message>
    <message>
        <location line="+25"/>
        <source>VERGE Core</source>
        <translation>VERGE Core</translation>
    </message>
    <message>
        <location line="+279"/>
        <source>Debug log file</source>
        <translation>Fichier de log Debug</translation>
    </message>
    <message>
        <location line="+7"/>
        <source>Open the VERGE debug log file from the current data directory. This can take a few seconds for large log files.</source>
        <translation>Ouvrir le fichier log de debug VERGE depuis le répertoire courant des données. Celà peut prendre quelques secondes pour les gros fichiers de logs.</translation>
    </message>
    <message>
        <location line="+102"/>
        <source>Clear console</source>
        <translation>Vider la console</translation>
    </message>
    <message>
        <location filename="../rpcconsole.cpp" line="-33"/>
        <source>Welcome to the VERGE RPC console.</source>
        <translation>Bienvenue dans la console RPC VERGE.</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Use up and down arrows to navigate history, and &lt;b&gt;Ctrl-L&lt;/b&gt; to clear screen.</source>
        <translation>Utiliser les flèches haut et bas pour naviguer dans l&apos;historique, et &lt;b&gt;Ctrl-L&lt;/b&gt; pour effacer l&apos;écran.</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Type &lt;b&gt;help&lt;/b&gt; for an overview of available commands.</source>
        <translation>Tapper &lt;b&gt;help&lt;/b&gt; pour un aperçu des commandes disponibless.</translation>
    </message>
</context>
<context>
    <name>SendCoinsDialog</name>
    <message>
        <location filename="../forms/sendcoinsdialog.ui" line="+14"/>
        <location filename="../sendcoinsdialog.cpp" line="+124"/>
        <location line="+5"/>
        <location line="+5"/>
        <location line="+5"/>
        <location line="+6"/>
        <location line="+5"/>
        <location line="+5"/>
        <source>Send Coins</source>
        <translation>Envoyer des pièces</translation>
    </message>
    <message>
        <location line="+50"/>
        <source>Send to multiple recipients at once</source>
        <translation>Envoyer à plusieurs destinataires à la fois</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Add &amp;Recipient</source>
        <translation>Ajouter &amp;Destinataire</translation>
    </message>
    <message>
        <location line="+20"/>
        <source>Remove all transaction fields</source>
        <translation>Retirer tous les champs de transactions</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Clear &amp;All</source>
        <translation>Effacer &amp;Tout</translation>
    </message>
    <message>
        <location line="+22"/>
        <source>Balance:</source>
        <translation>Balance:</translation>
    </message>
    <message>
        <location line="+10"/>
        <source>123.456 BTC</source>
        <translation>123.456 BTC</translation>
    </message>
    <message>
        <location line="+31"/>
        <source>Confirm the send action</source>
        <translation>Confirmer l&apos;action d&apos;envoi</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>S&amp;end</source>
        <translation>E&amp;nvoyer</translation>
    </message>
    <message>
        <location filename="../sendcoinsdialog.cpp" line="-59"/>
        <source>&lt;b&gt;%1&lt;/b&gt; to %2 (%3)</source>
        <translation>&lt;b&gt;%1&lt;/b&gt; vers %2 (%3)</translation>
    </message>
    <message>
        <location line="+5"/>
        <source>Confirm send coins</source>
        <translation>Confirmer l&apos;envoi des pièces</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Are you sure you want to send %1?</source>
        <translation>Etes vous sûr de vouloir envoyer %1?</translation>
    </message>
    <message>
        <location line="+0"/>
        <source> and </source>
        <translation> et </translation>
    </message>
    <message>
        <location line="+23"/>
        <source>The recipient address is not valid, please recheck.</source>
        <translation>L&apos;adresse du destinataie est invalide, merci de re-vérifier.</translation>
    </message>
    <message>
        <location line="+5"/>
        <source>The amount to pay must be larger than 0.</source>
        <translation>Le montant à payer doit être supérieur à 0.</translation>
    </message>
    <message>
        <location line="+5"/>
        <source>The amount exceeds your balance.</source>
        <translation>Le montant est supérieur à votre balance.</translation>
    </message>
    <message>
        <location line="+5"/>
        <source>The total exceeds your balance when the %1 transaction fee is included.</source>
        <translation>Le total est supérieur à votre balance avec les frais de transaction %1 inclus.</translation>
    </message>
    <message>
        <location line="+6"/>
        <source>Duplicate address found, can only send to each address once per send operation.</source>
        <translation>Deux adresses sont identiques, il n&apos;est possible d&apos;envoyer vers chaque adresse une seule fois par opération</translation>
    </message>
    <message>
        <location line="+5"/>
        <source>Error: Transaction creation failed.</source>
        <translation>Erreur: création de la transaction échouée.</translation>
    </message>
    <message>
        <location line="+5"/>
        <source>Error: The transaction was rejected. This might happen if some of the coins in your wallet were already spent, such as if you used a copy of wallet.dat and coins were spent in the copy but not marked as spent here.</source>
       <translation>Erreur: la transation a été rejectée. Celà peut arriver si certaines de vos pièces ont été déjà dépensées, par exemple si vous avez utilisé une copie de wallet.dat, et que vos pièces ont été utilisée dans la copie mais non marquées comme dépensées ici.</translation>
    </message>
</context>
<context>
    <name>SendCoinsEntry</name>
    <message>
        <location filename="../forms/sendcoinsentry.ui" line="+14"/>
        <source>Form</source>
        <translation>Formulaire</translation>
    </message>
    <message>
        <location line="+15"/>
        <source>A&amp;mount:</source>
        <translation>Q&amp;uantité:</translation>
    </message>
    <message>
        <location line="+13"/>
        <source>Pay &amp;To:</source>
        <translation>Payer &amp;à:</translation>
    </message>
    <message>
        <location line="+24"/>
        <location filename="../sendcoinsentry.cpp" line="+25"/>
        <source>Enter a label for this address to add it to your address book</source>
        <translation>Entrer un label pour cette address pour l&apos;ajouter à votre carnet d&apos;adresses</translation>
    </message>
    <message>
        <location line="+9"/>
        <source>&amp;Label:</source>
        <translation>&amp;Label:</translation>
    </message>
    <message>
        <location line="+18"/>
        <source>The address to send the payment to  (e.g. 4Zo1ga6xuKuQ7JV7M9rGDoxdbYwV5zgQJ5)</source>
        <translation>Adresse vers laquelle envoyer le paiement (ex: 4Zo1ga6xuKuQ7JV7M9rGDoxdbYwV5zgQJ5)</translation>
    </message>
    <message>
        <location line="+10"/>
        <source>Choose address from address book</source>
        <translation>Choisir une adresse depuis le carnet d&apos;adresses</translation>
    </message>
    <message>
        <location line="+10"/>
        <source>Alt+A</source>
        <translation>Alt+A</translation>
    </message>
    <message>
        <location line="+7"/>
        <source>Paste address from clipboard</source>
        <translation>Coller l&apos;adresse depuis le Presse-Papier</translation>
    </message>
    <message>
        <location line="+10"/>
        <source>Alt+P</source>
        <translation>Alt+P</translation>
    </message>
    <message>
        <location line="+7"/>
        <source>Remove this recipient</source>
        <translation>Supprimer ce destinataire</translation>
    </message>
    <message>
        <location filename="../sendcoinsentry.cpp" line="+1"/>
        <source>Enter a valid VERGE address</source>
        <translation>Entrer une adresse VERGE valide </translation>
    </message>
</context>
<context>
    <name>SignVerifyMessageDialog</name>
    <message>
        <location filename="../forms/signverifymessagedialog.ui" line="+14"/>
        <source>Signatures - Sign / Verify a Message</source>
        <translation>Signatures - Signer / Verifier un Message</translation>
    </message>
    <message>
        <location line="+13"/>
        <location line="+124"/>
        <source>&amp;Sign Message</source>
        <translation>&amp;Signer Message</translation>
    </message>
    <message>
        <location line="-118"/>
        <source>You can sign messages with your addresses to prove you own them. Be careful not to sign anything vague, as phishing attacks may try to trick you into signing your identity over to them. Only sign fully-detailed statements you agree to.</source>
        <translation>Vous pouvez signer les messages avec votre adresse pour prouver que vous les reconnaissez. Soyez attentif de ne pas signer quelque chose de vague, car des attaques de Phishing pourraient tenter de vous berner et vous faire signer. Signez uniquement des déclaration très détaillées avec lesquelles vous êtes en accord.</translation>
    </message>
    <message>
        <location line="+18"/>
        <source>The address to sign the message with </source>
        <translation>L&apos;adresse avec laquelle signer le message </translation>
    </message>
    <message>
        <location line="+10"/>
        <location line="+203"/>
        <source>Choose an address from the address book</source>
        <translation>Choisir une adresse depuis le carnet d&apos;adresse</translation>
    </message>
    <message>
        <location line="-193"/>
        <location line="+203"/>
        <source>Alt+A</source>
        <translation>Alt+A</translation>
    </message>
    <message>
        <location line="-193"/>
        <source>Paste address from clipboard</source>
        <translation>Coller l&apos;adresse depuis le Presse-Papier</translation>
    </message>
    <message>
        <location line="+10"/>
        <source>Alt+P</source>
        <translation>Alt+P</translation>
    </message>
    <message>
        <location line="+12"/>
        <source>Enter the message you want to sign here</source>
        <translation>Entrez le message que vous voulez signer ici</translation>
    </message>
    <message>
        <location line="+24"/>
        <source>Copy the current signature to the system clipboard</source>
        <translation>Copier la signature courante dans le Presse-Papier</translation>
    </message>
    <message>
        <location line="+21"/>
        <source>Sign the message to prove you own this VERGE address</source>
        <translation>Signer le message pour prouver que vous possédez cette adresse VERGE</translation>
    </message>
    <message>
        <location line="+17"/>
        <source>Reset all sign message fields</source>
        <translation>Réinitialiser tous les champs de signature du message</translation>
    </message>
    <message>
        <location line="+3"/>
        <location line="+146"/>
        <source>Clear &amp;All</source>
        <translation>Effacer &amp;Tout</translation>
    </message>
    <message>
        <location line="-87"/>
        <location line="+70"/>
        <source>&amp;Verify Message</source>
        <translation>&amp;Verifier Message</translation>
    </message>
    <message>
        <location line="-64"/>
        <source>Enter the signing address, message (ensure you copy line breaks, spaces, tabs, etc. exactly) and signature below to verify the message. Be careful not to read more into the signature than what is in the signed message itself, to avoid being tricked by a man-in-the-middle attack.</source>
        <translation>Entrer l&apos;adresse de signature, message (Assurez vous de copier les retours à la ligne, espaces, tabulations, etc. exactement), et la signature ci-dessous pour vérifier le message. Attention de ne pas lire plus dans la signature qu&apos;il n&apos;y avait dans le message signé, pour éviter une attaque de l&apos;homme du milieu.</translation>
    </message>
    <message>
        <location line="+21"/>
        <source>The address the message was signed with </source>
        <translation>Adresse avec laquelle le message a été signé </translation>
    </message>
    <message>
        <location line="+40"/>
        <source>Verify the message to ensure it was signed with the specified VERGE address</source>
        <translation>Vérifier le message pour s&apos;assurer qu&apos;il a été signé avec l&apos;adresse VERGE spécifiée</translation>
    </message>
    <message>
        <location line="+17"/>
        <source>Reset all verify message fields</source>
        <translation>Réinitialiser tous les champs de vérification de message</translation>
    </message>
    <message>
        <location filename="../signverifymessagedialog.cpp" line="+27"/>
        <location line="+3"/>
        <source>Enter a valid VERGE address</source>
        <translation>Entrer une adresse VERGE valide</translation>
    </message>
    <message>
        <location line="-2"/>
        <source>Click &quot;Sign Message&quot; to generate signature</source>
        <translation>Clicker &quot;Signer Message&quot; pour générer la signature</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Enter VERGE signature</source>
        <translation>Entrer la signature VERGE</translation>
    </message>
    <message>
        <location line="+82"/>
        <location line="+81"/>
        <source>The entered address is invalid.</source>
        <translation>L&apos;adresse entrée est invalide.</translation>
    </message>
    <message>
        <location line="-81"/>
        <location line="+8"/>
        <location line="+73"/>
        <location line="+8"/>
        <source>Please check the address and try again.</source>
        <translation>Merci de vérifier l&apos;adresse et d&apos;essayer à nouveau.</translation>
    </message>
    <message>
        <location line="-81"/>
        <location line="+81"/>
        <source>The entered address does not refer to a key.</source>
        <translation>L&apos;adresse entrée ne correspond pas à une clé.</translation>
    </message>
    <message>
        <location line="-73"/>
        <source>Wallet unlock was cancelled.</source>
        <translation>Le dévérouillage du portefeuille a été annulé.</translation>
    </message>
    <message>
        <location line="+8"/>
        <source>Private key for the entered address is not available.</source>
        <translation>La clé privée pour l&apos;adresse entrée n&apos;est pas disponible.</translation>
    </message>
    <message>
        <location line="+12"/>
        <source>Message signing failed.</source>
        <translation>Echec de la signature du message.</translation>
    </message>
    <message>
        <location line="+5"/>
        <source>Message signed.</source>
        <translation>Message signé.</translation>
    </message>
    <message>
        <location line="+59"/>
        <source>The signature could not be decoded.</source>
        <translation>La signature n&apos;a pas pu être décodée.</translation>
    </message>
    <message>
        <location line="+0"/>
        <location line="+13"/>
        <source>Please check the signature and try again.</source>
        <translation>Merci de vérifier la signature et d&apos;essayer à nouveau.</translation>
    </message>
    <message>
        <location line="+0"/>
        <source>The signature did not match the message digest.</source>
        <translation>La signature ne correspond pas au digest du message.</translation>
    </message>
    <message>
        <location line="+7"/>
        <source>Message verification failed.</source>
        <translation>Echec de la vérification du message.</translation>
    </message>
    <message>
        <location line="+5"/>
        <source>Message verified.</source>
        <translation>Message verifié.</translation>
    </message>
</context>
<context>
    <name>TransactionDesc</name>
    <message>
        <location filename="../transactiondesc.cpp" line="+19"/>
        <source>Open until %1</source>
        <translation>Ouvert jusqu&apos;à %1</translation>
    </message>
    <message numerus="yes">
        <location line="-2"/>
        <source>Open for %n block(s)</source>
        <translation>
            <numerusform>Ouvert pour %n bloc</numerusform>
            <numerusform>Ouvert pour %n blocs</numerusform>
        </translation>
    </message>
    <message>
        <location line="+8"/>
        <source>%1/offline</source>
        <translation>%1/déconnecté</translation>
    </message>
    <message>
        <location line="+2"/>
        <source>%1/unconfirmed</source>
        <translation>%1/non confirmé</translation>
    </message>
    <message>
        <location line="+2"/>
        <source>%1 confirmations</source>
        <translation>%1 confirmations</translation>
    </message>
    <message>
        <location line="+18"/>
        <source>Status</source>
        <translation>Status</translation>
    </message>
    <message numerus="yes">
        <location line="+7"/>
        <source>, broadcast through %n node(s)</source>
        <translation>
            <numerusform>, diffusion via %n noeud</numerusform>
            <numerusform>, diffusion via %n noeuds</numerusform>
        </translation>
    </message>
    <message>
        <location line="+4"/>
        <source>Date</source>
        <translation>Date</translation>
    </message>
    <message>
        <location line="+7"/>
        <source>Source</source>
        <translation>Source</translation>
    </message>
    <message>
        <location line="+0"/>
        <source>Generated</source>
        <translation>Généré</translation>
    </message>
    <message>
        <location line="+5"/>
        <location line="+17"/>
        <source>From</source>
        <translation>De</translation>
    </message>
    <message>
        <location line="+1"/>
        <location line="+22"/>
        <location line="+58"/>
        <source>To</source>
        <translation>à</translation>
    </message>
    <message>
        <location line="-77"/>
        <location line="+2"/>
        <source>own address</source>
        <translation>Mon adresse</translation>
    </message>
    <message>
        <location line="-2"/>
        <source>label</source>
        <translation>label</translation>
    </message>
    <message>
        <location line="+37"/>
        <location line="+12"/>
        <location line="+45"/>
        <location line="+17"/>
        <location line="+30"/>
        <source>Credit</source>
        <translation>Crédit</translation>
    </message>
    <message numerus="yes">
        <location line="-102"/>
        <source>matures in %n more block(s)</source>
        <translation>
            <numerusform>maturation dans %n bloc supplémentaire</numerusform>
            <numerusform>maturation dans %n blocs supplémentaires</numerusform>
        </translation>
    </message>
    <message>
        <location line="+2"/>
        <source>not accepted</source>
        <translation>non accepté</translation>
    </message>
    <message>
        <location line="+44"/>
        <location line="+8"/>
        <location line="+15"/>
        <location line="+30"/>
        <source>Debit</source>
        <translation>Débit</translation>
    </message>
    <message>
        <location line="-39"/>
        <source>Transaction fee</source>
        <translation>Frais de transaction</translation>
    </message>
    <message>
        <location line="+16"/>
        <source>Net amount</source>
        <translation>Montant net</translation>
    </message>
    <message>
        <location line="+6"/>
        <source>Message</source>
        <translation>Message</translation>
    </message>
    <message>
        <location line="+2"/>
        <source>Comment</source>
        <translation>Commentaire</translation>
    </message>
    <message>
        <location line="+2"/>
        <source>Transaction ID</source>
        <translation>ID de Transaction</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Generated coins must mature 25 blocks before they can be spent. When you generated this block, it was broadcast to the network to be added to the block chain. If it fails to get into the chain, its state will change to &quot;not accepted&quot; and it won&apos;t be spendable. This may occasionally happen if another node generates a block within a few seconds of yours.</source>
        <translation>Les pièces générées doivent murir 25 blocs avant de pouvoir être dépensées. Lorsque vous avez généré ce bloc, il a été diffusé au réseau pour être ajouté à la chaîne de blocs. Si l&apos;ajout dans la chaîne échoue, son statut va changer en &quot;non accepté&quot; et il ne pourra pas être dépensé. Celà peut arriver occasionellement si un autre noeud génère un bloc dans les quelques secondes suivant le vôtre.</translation>
    </message>
    <message>
        <location line="+4"/>
        <source>Staked coins must wait 25 blocks before they can return to balance and be spent.  When you generated this proof-of-stake block, it was broadcast to the network to be added to the block chain.  If it fails to get into the chain, it will change to \"not accepted\" and not be a valid stake.  This may occasionally happen if another node generates a proof-of-stake block within a few seconds of yours.</source>
        <translation>Les pièces d&apos;enjeu divent attendre 25 blocks avant de retourner dans la balance et être dépensées.  Lorsque vous avez généré ce bloc de preuve d&apos;enjeu, il a été diffusé au réseau pour être ajouté à la chaîne de blocs. Si l&apos;ajout dans la chaîne échoue, son statut va changer en &quot;non accepté&quot; et il ne pourra pas être dépensé. Celà peut arriver occasionellement si un autre noeud génère un bloc avec preuve d&apos;enjeu dans les quelques secondes suivant le vôtre.</translation>
    </message>
    <message>
        <location line="+7"/>
        <source>Debug information</source>
        <translation>Informations de Debug</translation>
    </message>
    <message>
        <location line="+8"/>
        <source>Transaction</source>
        <translation>Transaction</translation>
    </message>
    <message>
        <location line="+5"/>
        <source>Inputs</source>
        <translation>Entrées</translation>
    </message>
    <message>
        <location line="+23"/>
        <source>Amount</source>
        <translation>Quantité</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>true</source>
        <translation>vrai</translation>
    </message>
    <message>
        <location line="+0"/>
        <source>false</source>
        <translation>faux</translation>
    </message>
    <message>
        <location line="-211"/>
        <source>, has not been successfully broadcast yet</source>
        <translation>, n&apos;a pas été diffusé avec succès pour l&apos;instant</translation>
    </message>
    <message>
        <location line="+35"/>
        <source>unknown</source>
        <translation>inconnu</translation>
    </message>
</context>
<context>
    <name>TransactionDescDialog</name>
    <message>
        <location filename="../forms/transactiondescdialog.ui" line="+14"/>
        <source>Transaction details</source>
        <translation>Détails de transaction</translation>
    </message>
    <message>
        <location line="+6"/>
        <source>This pane shows a detailed description of the transaction</source>
        <translation>Cet écran montre une description détaillée de la transaction</translation>
    </message>
</context>
<context>
    <name>TransactionTableModel</name>
    <message>
        <location filename="../transactiontablemodel.cpp" line="+226"/>
        <source>Date</source>
        <translation>Date</translation>
    </message>
    <message>
        <location line="+0"/>
        <source>Type</source>
        <translation>Type</translation>
    </message>
    <message>
        <location line="+0"/>
        <source>Address</source>
        <translation>Adresse</translation>
    </message>
    <message>
        <location line="+0"/>
        <source>Amount</source>
        <translation>Quantité</translation>
    </message>
    <message numerus="yes">
        <location line="+57"/>
        <source>Open for %n block(s)</source>
        <translation>
            <numerusform>Ouvert pour %n bloc</numerusform>
            <numerusform>Ouvert pour %n blocs</numerusform>
        </translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Open until %1</source>
        <translation>Ouvert jusque %1</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Offline (%1 confirmations)</source>
        <translation>Déconnecté (%1 confirmations)</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Unconfirmed (%1 of %2 confirmations)</source>
        <translation>Non confirmé (%1 of %2 confirmations)</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Confirmed (%1 confirmations)</source>
        <translation>Confirmé (%1 confirmations)</translation>
    </message>
    <message numerus="yes">
        <location line="+8"/>
        <source>Mined balance will be available when it matures in %n more block(s)</source>
        <translation>
            <numerusform>Mined balance will be available when it matures in %n more block</numerusform>
            <numerusform>La balance minée sera disponible lorsque elle aura muri dans %n bloc</numerusform>
        </translation>
    </message>
    <message>
        <location line="+5"/>
        <source>This block was not received by any other nodes and will probably not be accepted!</source>
        <translation>Ce bloc n&apos;a été reçu par aucun autre noeud et ne sera probablement pas accepté!</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Generated but not accepted</source>
        <translation>Généré mais non accepté</translation>
    </message>
    <message>
        <location line="+43"/>
        <source>Received with</source>
        <translation>Reçu avec</translation>
    </message>
    <message>
        <location line="+2"/>
        <source>Received from</source>
        <translation>Reçu de</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Sent to</source>
        <translation>Envoyé à</translation>
    </message>
    <message>
        <location line="+2"/>
        <source>Payment to yourself</source>
        <translation>Paiement à vous-même</translation>
    </message>
    <message>
        <location line="+2"/>
        <source>Mined</source>
        <translation>Miné</translation>
    </message>
    <message>
        <location line="+38"/>
        <source>(n/a)</source>
        <translation>(n/a)</translation>
    </message>
    <message>
        <location line="+199"/>
        <source>Transaction status. Hover over this field to show number of confirmations.</source>
        <translation>Statut de Transaction. Passer au dessus de ce champ pour afficher le nombre de confirmations.</translation>
    </message>
    <message>
        <location line="+2"/>
        <source>Date and time that the transaction was received.</source>
        <translation>Date et heure à laquelle la transaction a été reçue.</translation>
    </message>
    <message>
        <location line="+2"/>
        <source>Type of transaction.</source>
        <translation>Type de transaction.</translation>
    </message>
    <message>
        <location line="+2"/>
        <source>Destination address of transaction.</source>
        <translation>Adresse de destination de la transaction.</translation>
    </message>
    <message>
        <location line="+2"/>
        <source>Amount removed from or added to balance.</source>
        <translation>Quantité retirée ou ajoutée à la balance.</translation>
    </message>
</context>
<context>
    <name>TransactionView</name>
    <message>
        <location filename="../transactionview.cpp" line="+55"/>
        <location line="+16"/>
        <source>All</source>
        <translation>Tout</translation>
    </message>
    <message>
        <location line="-15"/>
        <source>Today</source>
        <translation>Aujourd&apos;hui</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>This week</source>
        <translation>Cette semaine</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>This month</source>
        <translation>Ce mois</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Last month</source>
        <translation>Mois dernier</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>This year</source>
        <translation>Cette année</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Range...</source>
        <translation>Range...</translation>
    </message>
    <message>
        <location line="+11"/>
        <source>Received with</source>
        <translation>Reçu avec</translation>
    </message>
    <message>
        <location line="+2"/>
        <source>Sent to</source>
        <translation>Envoyé à</translation>
    </message>
    <message>
        <location line="+2"/>
        <source>To yourself</source>
        <translation>A vous-même</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Mined</source>
        <translation>Miné</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Other</source>
        <translation>Autre</translation>
    </message>
    <message>
        <location line="+7"/>
        <source>Enter address or label to search</source>
        <translation>Entrer l&apos;adresse ou le label à chercher</translation>
    </message>
    <message>
        <location line="+7"/>
        <source>Min amount</source>
        <translation>Quantité minimum</translation>
    </message>
    <message>
        <location line="+34"/>
        <source>Copy address</source>
        <translation>Copier adresse</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Copy label</source>
        <translation>Copier label</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Copy amount</source>
        <translation>Copier quantité</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Edit label</source>
        <translation>Editer label</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Show transaction details</source>
        <translation>Montrer les détails de transaction</translation>
    </message>
    <message>
        <location line="+142"/>
        <source>Export Transaction Data</source>
        <translation>Exporter les données de transaction</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Comma separated file (*.csv)</source>
        <translation>Comma separated file (*.csv)</translation>
    </message>
    <message>
        <location line="+8"/>
        <source>Confirmed</source>
        <translation>Confirmé</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Date</source>
        <translation>Date</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Type</source>
        <translation>Type</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Label</source>
        <translation>Label</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Address</source>
        <translation>Adresse</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Amount</source>
        <translation>Quantité</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>ID</source>
        <translation>ID</translation>
    </message>
    <message>
        <location line="+4"/>
        <source>Error exporting</source>
        <translation>Error d&apos;exportation</translation>
    </message>
    <message>
        <location line="+0"/>
        <source>Could not write to file %1.</source>
        <translation>Impossible d&apos;écrire dans le fichier %1.</translation>
    </message>
    <message>
        <location line="+95"/>
        <source>Range:</source>
        <translation>Range:</translation>
    </message>
    <message>
        <location line="+8"/>
        <source>to</source>
        <translation>à</translation>
    </message>
</context>
<context>
    <name>WalletModel</name>
    <message>
        <location filename="../walletmodel.cpp" line="+192"/>
        <source>Sending...</source>
        <translation>Envoi en cours...</translation>
    </message>
</context>
<context>
    <name>bitcoin-core</name>
    <message>
        <location filename="../bitcoinstrings.cpp" line="+82"/>
        <source>VERGE version</source>
        <translation>Version VERGE</translation>
    </message>
    <message>
        <location line="+82"/>
        <source>Usage:</source>
        <translation>Utilisation:</translation>
    </message>
    <message>
        <location line="-25"/>
        <source>Send command to -server or bitcoind</source>
        <translation>Envoie la commande à -server ou bitcoind</translation>
    </message>
    <message>
        <location line="-19"/>
        <source>List commands</source>
        <translation>Lister commandes</translation>
    </message>
    <message>
        <location line="-11"/>
        <source>Get help for a command</source>
        <translation>Obtenir de l&apos;aide pour une commande</translation>
    </message>
    <message>
        <location line="+20"/>
        <source>Options:</source>
        <translation>Options:</translation>
    </message>
    <message>
        <location line="+23"/>
        <source>Specify configuration file (default: VERGE.conf)</source>
        <translation>Spécifier le fichier de configuration (defaut: VERGE.conf)</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Specify pid file (default: VERGEd.pid)</source>
        <translation>Specifier le fichier pid (defalt: VERGEd.pid)</translation>
    </message>
    <message>
        <location line="-47"/>
        <source>Generate coins</source>
        <translation>Générer pièces</translation>
    </message>
    <message>
        <location line="-14"/>
        <source>Don&apos;t generate coins</source>
        <translation>Ne pas générer de pièces</translation>
    </message>
    <message>
        <location line="+60"/>
        <source>Specify data directory</source>
        <translation>Spécifier le répertoire de donnée</translation>
    </message>
    <message>
        <location line="-8"/>
        <source>Set database cache size in megabytes (default: 25)</source>
        <translation>Définir la taille du cache en megabytes (defaut: 25)</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Set database disk log size in megabytes (default: 100)</source>
        <translation>Définir la taille du log disque de la base de donnée en megabytes (default: 100)</translation>
    </message>
    <message>
        <location line="-26"/>
        <source>Listen for connections on &lt;port&gt; (default: 7777 or testnet: 17777)</source>
        <translation>Ecouter les connexion sur &lt;port&gt; (defaut: 21102 ou testnet: 18333)</translation>
    </message>
    <message>
        <location line="+4"/>
        <source>Maintain at most &lt;n&gt; connections to peers (default: 125)</source>
        <translation>Maintenir au moins &lt;n&gt; connexions avec les pairs (defaut: 125)</translation>
    </message>
    <message>
        <location line="-33"/>
        <source>Connect to a node to retrieve peer addresses, and disconnect</source>
        <translation>Connecter pour retrouver les adresses des pairs, et déconnecter</translation>
    </message>
    <message>
        <location line="+64"/>
        <source>Specify your own public address</source>
        <translation>Spécifier votre adresse publique</translation>
    </message>
    <message>
        <location line="-75"/>
        <source>Bind to given address. Use [host]:port notation for IPv6</source>
        <translation>Utiliser une adresse spécifique. Utiliser la notation [host]:port pour IPv6</translation>
    </message>
    <message>
        <location line="+77"/>
        <source>Threshold for disconnecting misbehaving peers (default: 100)</source>
        <translation>Seuil pour déconnecter les pairs avec un mauvais comportement (defaut: 100)</translation>
    </message>
    <message>
        <location line="-112"/>
        <source>Number of seconds to keep misbehaving peers from reconnecting (default: 86400)</source>
        <translation>Nombre de secondes avant reconnexion des pair avec mauvais comportement (defaut: 86400)</translation>
    </message>
    <message>
        <location line="-25"/>
        <source>An error occurred while setting up the RPC port %u for listening on IPv4: %s</source>
        <translation>Erreur lors de la configuration du port RPC %u pour écouter sur IPv4: %s</translation>
    </message>
    <message>
        <location line="+8"/>
        <source>Detach block and address databases. Increases shutdown time (default: 0)</source>
        <translation>Détachement des bases de données de blocs et d'adresses. Augmente le temps d'arrêt (defaut: 0)</translation>
    </message>
    <message>
        <location line="+5"/>
        <source>Error: The transaction was rejected.  This might happen if some of the coins in your wallet were already spent, such as if you used a copy of wallet.dat and coins were spent in the copy but not marked as spent here.</source>
        <translation>Erreur: la transaction a été rejetée. Celà peut arriver si certaines de vos pièces ont été déjà dépensées, par exemple si vous avez utilisé une copie de wallet.dat, et que vos pièces ont été utilisée dans la copie mais non marquées comme dépensées ici.</translation>
    </message>
    <message>
        <location line="+4"/>
        <source>Error: This transaction requires a transaction fee of at least %s because of its amount, complexity, or use of recently received funds  </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+6"/>
        <source>Listen for JSON-RPC connections on &lt;port&gt; (default: 8344 or testnet: 18344)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+31"/>
        <source>Accept command line and JSON-RPC commands</source>
        <translation>Accept command line and JSON-RPC commands</translation>
    </message>
    <message>
        <location line="+26"/>
        <source>Error: Transaction creation failed  </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Error: Wallet locked, unable to create transaction  </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+10"/>
        <source>Importing blockchain data file.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Importing bootstrap blockchain data file.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+23"/>
        <source>Run in the background as a daemon and accept commands</source>
        <translation>Run in the background as a daemon and accept commands</translation>
    </message>
    <message>
        <location line="+33"/>
        <source>Use the test network</source>
        <translation>Use the test network</translation>
    </message>
    <message>
        <location line="-93"/>
        <source>Accept connections from outside (default: 1 if no -proxy or -connect)</source>
        <translation>Accept connections from outside (default: 1 if no -proxy or -connect)</translation>
    </message>
    <message>
        <location line="-53"/>
        <source>An error occurred while setting up the RPC port %u for listening on IPv6, falling back to IPv4: %s</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+8"/>
        <source>Error initializing database environment %s! To recover, BACKUP THAT DIRECTORY, then remove everything from it except for wallet.dat.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+18"/>
        <source>Set maximum size of high-priority/low-fee transactions in bytes (default: 27000)</source>
        <translation>Set maximum size of high-priority/low-fee transactions in bytes (default: 27000)</translation>
    </message>
    <message>
        <location line="+5"/>
        <source>Warning: -paytxfee is set very high! This is the transaction fee you will pay if you send a transaction.</source>
        <translation>Warning: -paytxfee is set very high! This is the transaction fee you will pay if you send a transaction.</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Warning: Displayed transactions may not be correct! You may need to upgrade, or other nodes may need to upgrade.</source>
        <translation>Warning: Displayed transactions may not be correct! You may need to upgrade, or other nodes may need to upgrade.</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Warning: Please check that your computer&apos;s date and time are correct! If your clock is wrong VERGE will not work properly.</source>
        <translation>Warning: Please check that your computer&apos;s date and time are correct! If your clock is wrong VERGE will not work properly.</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Warning: error reading wallet.dat! All keys read correctly, but transaction data or address book entries might be missing or incorrect.</source>
        <translation>Warning: error reading wallet.dat! All keys read correctly, but transaction data or address book entries might be missing or incorrect.</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Warning: wallet.dat corrupt, data salvaged! Original wallet.dat saved as wallet.{timestamp}.bak in %s; if your balance or transactions are incorrect you should restore from a backup.</source>
        <translation>Warning: wallet.dat corrupt, data salvaged! Original wallet.dat saved as wallet.{timestamp}.bak in %s; if your balance or transactions are incorrect you should restore from a backup.</translation>
    </message>
    <message>
        <location line="+14"/>
        <source>Attempt to recover private keys from a corrupt wallet.dat</source>
        <translation>Attempt to recover private keys from a corrupt wallet.dat</translation>
    </message>
    <message>
        <location line="+4"/>
        <source>Block creation options:</source>
        <translation>Block creation options:</translation>
    </message>
    <message>
        <location line="+6"/>
        <source>Connect only to the specified node(s)</source>
        <translation>Connect only to the specified node(s)</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Discover own IP address (default: 1 when listening and no -externalip)</source>
        <translation>Discover own IP address (default: 1 when listening and no -externalip)</translation>
    </message>
    <message>
        <location line="+11"/>
        <source>Failed to listen on any port. Use -listen=0 if you want this.</source>
        <translation>Failed to listen on any port. Use -listen=0 if you want this.</translation>
    </message>
    <message>
        <location line="+2"/>
        <source>Find peers using DNS lookup (default: 0)</source>
        <translation>Find peers using DNS lookup (default: 0)</translation>
    </message>
    <message>
        <location line="+11"/>
        <source>Invalid -tor address: &apos;%s&apos;</source>
        <translation>Invalid -tor address: &apos;%s&apos;</translation>
    </message>
    <message>
        <location line="+9"/>
        <source>Maximum per-connection receive buffer, &lt;n&gt;*1000 bytes (default: 5000)</source>
        <translation>Maximum per-connection receive buffer, &lt;n&gt;*1000 bytes (default: 5000)</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Maximum per-connection send buffer, &lt;n&gt;*1000 bytes (default: 1000)</source>
        <translation>Maximum per-connection send buffer, &lt;n&gt;*1000 bytes (default: 1000)</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Only connect to nodes in network &lt;net&gt; (IPv4, IPv6 or Tor)</source>
        <translation>Only connect to nodes in network &lt;net&gt; (IPv4, IPv6 or Tor)</translation>
    </message>
    <message>
        <location line="+2"/>
        <source>Output extra debugging information. Implies all other -debug* options</source>
        <translation>Output extra debugging information. Implies all other -debug* options</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Output extra network debugging information</source>
        <translation>Output extra network debugging information</translation>
    </message>
    <message>
        <location line="+2"/>
        <source>Prepend debug output with timestamp</source>
        <translation>Prepend debug output with timestamp</translation>
    </message>
    <message>
        <location line="+4"/>
        <source>SSL options: (see the Bitcoin Wiki for SSL setup instructions)</source>
        <translation>SSL options: (see the Bitcoin Wiki for SSL setup instructions)</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Select the version of socks proxy to use (4-5, default: 5)</source>
        <translation>Select the version of socks proxy to use (4-5, default: 5)</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Send trace/debug info to console instead of debug.log file</source>
        <translation>Send trace/debug info to console instead of debug.log file</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Send trace/debug info to debugger</source>
        <translation>Send trace/debug info to debugger</translation>
    </message>
    <message>
        <location line="+7"/>
        <source>Set maximum block size in bytes (default: 250000)</source>
        <translation>Set maximum block size in bytes (default: 250000)</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Set minimum block size in bytes (default: 0)</source>
        <translation>Set minimum block size in bytes (default: 0)</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Shrink debug.log file on client startup (default: 1 when no -debug)</source>
        <translation>Shrink debug.log file on client startup (default: 1 when no -debug)</translation>
    </message>
    <message>
        <location line="+2"/>
        <source>Specify connection timeout in milliseconds (default: 5000)</source>
        <translation>Specify connection timeout in milliseconds (default: 5000)</translation>
    </message>
    <message>
        <location line="+13"/>
        <source>Use UPnP to map the listening port (default: 0)</source>
        <translation>Use UPnP to map the listening port (default: 0)</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Use UPnP to map the listening port (default: 1 when listening)</source>
        <translation>Use UPnP to map the listening port (default: 1 when listening)</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Use proxy to reach tor hidden services (default: same as -proxy)</source>
        <translation>Use proxy to reach tor hidden services (default: same as -proxy)</translation>
    </message>
    <message>
        <location line="+2"/>
        <source>Username for JSON-RPC connections</source>
        <translation>Username for JSON-RPC connections</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Verifying database integrity...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+2"/>
        <source>Warning: Disk space is low!</source>
        <translation>Warning: Disk space is low!</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Warning: This version is obsolete, upgrade required!</source>
        <translation>Warning: This version is obsolete, upgrade required!</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>wallet.dat corrupt, salvage failed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="-43"/>
        <source>Password for JSON-RPC connections</source>
        <translation>Password for JSON-RPC connections</translation>
    </message>
    <message>
        <location line="-53"/>
        <source>Allow JSON-RPC connections from specified IP address</source>
        <translation>Allow JSON-RPC connections from specified IP address</translation>
    </message>
    <message>
        <location line="+61"/>
        <source>Send commands to node running on &lt;ip&gt; (default: 127.0.0.1)</source>
        <translation>Send commands to node running on &lt;ip&gt; (default: 127.0.0.1)</translation>
    </message>
    <message>
        <location line="-99"/>
        <source>Execute command when the best block changes (%s in cmd is replaced by block hash)</source>
        <translation>Execute command when the best block changes (%s in cmd is replaced by block hash)</translation>
    </message>
    <message>
        <location line="+122"/>
        <source>Upgrade wallet to latest format</source>
        <translation>Upgrade wallet to latest format</translation>
    </message>
    <message>
        <location line="-15"/>
        <source>Set key pool size to &lt;n&gt; (default: 100)</source>
        <translation>Set key pool size to &lt;n&gt; (default: 100)</translation>
    </message>
    <message>
        <location line="-14"/>
        <source>Rescan the block chain for missing wallet transactions</source>
        <translation>Rescan the block chain for missing wallet transactions</translation>
    </message>
    <message>
        <location line="-24"/>
        <source>How many blocks to check at startup (default: 2500, 0 = all)</source>
        <translation>How many blocks to check at startup (default: 2500, 0 = all)</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>How thorough the block verification is (0-6, default: 1)</source>
        <translation>How thorough the block verification is (0-6, default: 1)</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Imports blocks from external blk000?.dat file</source>
        <translation>Imports blocks from external blk000?.dat file</translation>
    </message>
    <message>
        <location line="+51"/>
        <source>Use OpenSSL (https) for JSON-RPC connections</source>
        <translation>Use OpenSSL (https) for JSON-RPC connections</translation>
    </message>
    <message>
        <location line="-21"/>
        <source>Server certificate file (default: server.cert)</source>
        <translation>Server certificate file (default: server.cert)</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Server private key (default: server.pem)</source>
        <translation>Server private key (default: server.pem)</translation>
    </message>
    <message>
        <location line="-127"/>
        <source>Acceptable ciphers (default: TLSv1+HIGH:!SSLv2:!aNULL:!eNULL:!AH:!3DES:@STRENGTH)</source>
        <translation>Acceptable ciphers (default: TLSv1+HIGH:!SSLv2:!aNULL:!eNULL:!AH:!3DES:@STRENGTH)</translation>
    </message>
    <message>
        <location line="+139"/>
        <source>This help message</source>
        <translation>This help message</translation>
    </message>
    <message>
        <location line="-131"/>
        <source>Cannot obtain a lock on data directory %s.  VERGE is probably already running.</source>
        <translation>Cannot obtain a lock on data directory %s.  VERGE is probably already running.</translation>
    </message>
    <message>
        <location line="+57"/>
        <source>VERGE</source>
        <translation>VERGE</translation>
    </message>
    <message>
        <location line="+77"/>
        <source>Unable to bind to %s on this computer (bind returned error %d, %s)</source>
        <translation>Unable to bind to %s on this computer (bind returned error %d, %s)</translation>
    </message>
    <message>
        <location line="-69"/>
        <source>Connect through socks proxy</source>
        <translation>Connect through socks proxy</translation>
    </message>
    <message>
        <location line="-13"/>
        <source>Allow DNS lookups for -addnode, -seednode and -connect</source>
        <translation>Allow DNS lookups for -addnode, -seednode and -connect</translation>
    </message>
    <message>
        <location line="+44"/>
        <source>Loading addresses...</source>
        <translation>Loading addresses...</translation>
    </message>
    <message>
        <location line="-26"/>
        <source>Error loading blkindex.dat</source>
        <translation>Error loading blkindex.dat</translation>
    </message>
    <message>
        <location line="+2"/>
        <source>Error loading wallet.dat: Wallet corrupted</source>
        <translation>Error loading wallet.dat: Wallet corrupted</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Error loading wallet.dat: Wallet requires newer version of VERGE</source>
        <translation>Error loading wallet.dat: Wallet requires newer version of VERGE</translation>
    </message>
    <message>
        <location line="+73"/>
        <source>Wallet needed to be rewritten: restart VERGE to complete</source>
        <translation>Wallet needed to be rewritten: restart VERGE to complete</translation>
    </message>
    <message>
        <location line="-75"/>
        <source>Error loading wallet.dat</source>
        <translation>Error loading wallet.dat</translation>
    </message>
    <message>
        <location line="+19"/>
        <source>Invalid -proxy address: &apos;%s&apos;</source>
        <translation>Invalid -proxy address: &apos;%s&apos;</translation>
    </message>
    <message>
        <location line="+46"/>
        <source>Unknown network specified in -onlynet: &apos;%s&apos;</source>
        <translation>Unknown network specified in -onlynet: &apos;%s&apos;</translation>
    </message>
    <message>
        <location line="-1"/>
        <source>Unknown -socks proxy version requested: %i</source>
        <translation>Unknown -socks proxy version requested: %i</translation>
    </message>
    <message>
        <location line="-74"/>
        <source>Cannot resolve -bind address: &apos;%s&apos;</source>
        <translation>Cannot resolve -bind address: &apos;%s&apos;</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Cannot resolve -externalip address: &apos;%s&apos;</source>
        <translation>Cannot resolve -externalip address: &apos;%s&apos;</translation>
    </message>
    <message>
        <location line="+30"/>
        <source>Invalid amount for -paytxfee=&lt;amount&gt;: &apos;%s&apos;</source>
        <translation>Invalid amount for -paytxfee=&lt;amount&gt;: &apos;%s&apos;</translation>
    </message>
    <message>
        <location line="-15"/>
        <source>Error: could not start node</source>
        <translation>Error: could not start node</translation>
    </message>
    <message>
        <location line="+40"/>
        <source>Sending...</source>
        <translation>Sending...</translation>
    </message>
    <message>
        <location line="-24"/>
        <source>Invalid amount</source>
        <translation>Invalid amount</translation>
    </message>
    <message>
        <location line="-4"/>
        <source>Insufficient funds</source>
        <translation>Insufficient funds</translation>
    </message>
    <message>
        <location line="+8"/>
        <source>Loading block index...</source>
        <translation>Loading block index...</translation>
    </message>
    <message>
        <location line="-46"/>
        <source>Add a node to connect to and attempt to keep the connection open</source>
        <translation>Add a node to connect to and attempt to keep the connection open</translation>
    </message>
    <message>
        <location line="-25"/>
        <source>Unable to bind to %s on this computer. VERGE is probably already running.</source>
        <translation>Unable to bind to %s on this computer. VERGE is probably already running.</translation>
    </message>
    <message>
        <location line="+55"/>
        <source>Find peers using internet relay chat (default: 1)</source>
        <translation>Find peers using internet relay chat (default: 1)</translation>
    </message>
    <message>
        <location line="-2"/>
        <source>Fee per KB to add to transactions you send</source>
        <translation>Fee per KB to add to transactions you send</translation>
    </message>
    <message>
        <location line="+19"/>
        <source>Loading wallet...</source>
        <translation>Loading wallet...</translation>
    </message>
    <message>
        <location line="-39"/>
        <source>Cannot downgrade wallet</source>
        <translation>Cannot downgrade wallet</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Cannot initialize keypool</source>
        <translation>Cannot initialize keypool</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Cannot write default address</source>
        <translation>Cannot write default address</translation>
    </message>
    <message>
        <location line="+46"/>
        <source>Rescanning...</source>
        <translation>Rescanning...</translation>
    </message>
    <message>
        <location line="-40"/>
        <source>Done loading</source>
        <translation>Done loading</translation>
    </message>
    <message>
        <location line="+64"/>
        <source>To use the %s option</source>
        <translation>To use the %s option</translation>
    </message>
    <message>
        <location line="-150"/>
        <source>%s, you must set a rpcpassword in the configuration file:
 %s
It is recommended you use the following random password:
rpcuser=bitcoinrpc
rpcpassword=%s
(you do not need to remember this password)
If the file does not exist, create it with owner-readable-only file permissions.
</source>
        <translation>%s, you must set a rpcpassword in the configuration file:
 %s
It is recommended you use the following random password:
rpcuser=bitcoinrpc
rpcpassword=%s
(you do not need to remember this password)
If the file does not exist, create it with owner-readable-only file permissions.
</translation>
    </message>
    <message>
        <location line="+91"/>
        <source>Error</source>
        <translation>Error</translation>
    </message>
    <message>
        <location line="-30"/>
        <source>You must set rpcpassword=&lt;password&gt; in the configuration file:
%s
If the file does not exist, create it with owner-readable-only file permissions.</source>
        <translation>You must set rpcpassword=&lt;password&gt; in the configuration file:
%s
If the file does not exist, create it with owner-readable-only file permissions.</translation>
    </message>
</context>
</TS>
