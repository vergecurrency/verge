To build:
---
    docker build --rm -t vergecurrency/verge:2.1.0-fedora23 .

See the instructions in the ubunt14 docker for how to use

