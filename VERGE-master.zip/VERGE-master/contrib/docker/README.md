Started from this:
   https://github.com/vergecurrency/Docker-Verge-Daemon

However, the official docker images can be found here:
   https://hub.docker.com/r/vergecurrency/verge/

