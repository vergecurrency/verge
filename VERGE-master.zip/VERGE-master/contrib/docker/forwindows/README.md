Note: This is for cross compiling windows binaries using ubuntu

To build:
---
    docker build --rm -t verge:forwindows .


