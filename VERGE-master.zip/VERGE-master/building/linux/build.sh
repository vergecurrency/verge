./autogen.sh
./configure --with-gui=qt5
make
